python3 reset_db.py
